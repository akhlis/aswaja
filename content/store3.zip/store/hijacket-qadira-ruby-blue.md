---
title: Hijacket Qadira Ruby Blue - HJ-QD
description: Jual jaket muslimah Hijacket Qadira Ruby Blue - HJ-QD
date: '2018-09-04T17:48:14+07:00'
slug: QD-RUBY-BLUE
tags:
  - qadira
  - red
produk:
  - qadira
brand:
  - hijacket
thumbnail: /images/qd-ruby-blue.jpg
images:
  - /images/qd-ruby-blue-1.jpg
  - /images/qd-ruby-blue-2.jpg
  - /images/qd-ruby-blue-3.jpg
  - /images/qd-ruby-blue-4.jpg
  - /images/qd-ruby-blue-5.jpg
  - /images/qd-ruby-blue-6.jpg
  - /images/qd-ruby-blue-7.jpg
sku: QD-RUBY-BLUE
badge: sale
berat: 620 gram
color:
  - Ruby Blue
size:
  - name: All Size
    price: 210000
  - name: XL
    price: 220000
stock: true
layout: multi-varian
---

Hijacket Qadira Original merupakan seri hijacket sporty terbaru dirancacng lebih Modis dilengkapi dengan Bordir berkualitas dengan Identitas Hijaber (HJ) dibagian dada ditambah kata motivasi _“Hijab Makes Me Complete Hijacket Makes Me Perfect”_ dan _“Strength and Dignity Hijaber Forever”_. Sangat cocok untuk menyempurnakan gaya hijabmu dengan design yang Fresh dan paduan warna yang menarik.

- ▶ Ukuran : ALL SIZE FIT TO L hingga XL (XL Nambah 10.000)

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Sablonan Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 4 variasi warna Hijacket Qadira Original, pilih style favorit ukhti❤

#### Tabel Ukuran Hijacket Qadira Original


| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 84-85           | 86-87  	      |