---
title: Hijacket Elma Blackberry - HJ-EL
description: Jual jaket muslimah Hijacket Elma Blackberry - HJ-EL - HJ-EL
date: '2018-07-15T17:48:14+07:00'
slug: EL-BLACKBERRY
tags:
  - elma
  - black
produk:
  - elma
brand:
  - hijacket
featured:
  - ''
thumbnail: /images/el-blackberry.jpg
images:
  - /images/el-blackberry-1.jpg
  - /images/el-blackberry-2.jpg
  - /images/el-blackberry-3.jpg
  - /images/el-blackberry-4.jpg
  - /images/el-blackberry-5.jpg
  - /images/el-blackberry-6.jpg
  - /images/el-blackberry-7.jpg
sku: EL-BLACKBERRY
badge: sale
berat: 715 gram
color:
  - Blackberry
size:
  - name: All Size
    price: 195000
  - name: XL
    price: 205000
stock: true
layout: multi-varian
---

HIJACKET  ELMA ORIGINAL merupakan  seri hijacket gaya modern yang tak lekang oleh waktu, hijacket elma dilengkapi dengan bentuk feminin, saku yang praktis dan pas serbaguna dan dengan tombol pearlescent vintage-chic. Sangat cocok untuk hijaber yang suka tampil formal dan berstyle jas.

- ▶️ Ukuran : ALL SIZE FIT TO L hingga XL (XL Nambah 10.000)

- ▶️ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶️ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶️ Bordir Berkualitas

- ▶️ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶️ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 4 variasi warna Hijacket Elma Original

#### Tabel Ukuran Hijacket Elma Original


| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 89-90           | 89-90  	      |