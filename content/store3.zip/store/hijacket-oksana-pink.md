---
title: Hijacket Oksana Pink - HJ-OK
description: Jual jaket muslimah Hijacket Oksana Pink - HJ-OK
date: '2018-11-22T17:48:14+07:00'
slug: OK-PINK
tags:
  - oksana
  - pink
produk:
  - oksana
brand:
  - hijacket
thumbnail: /images/oksana-pink.jpg
images:
  - /images/oksana-pink-1.jpg
  - /images/oksana-pink-2.jpg
  - /images/oksana-pink-3.jpg
  - /images/oksana-pink-4.jpg
  - /images/oksana-pink-5.jpg
  - /images/oksana-pink-6.jpg
  - /images/oksana-pink-7.jpg
  - /images/oksana-pink-8.jpg
sku: OK-PINK
badge: new
berat: 730 gram
color:
  - Pink
size: All Size
price: 200000
stock: true
---

Hijacket OKSANA dibuat untuk para hijaber yang aktif dengan rancangan gaya jari yang memenuhi kebutuhan Hijaber dan warna yang berbeda dari 2 sisi nya, Menjadikan seri ini wajib kamu pakai kemana pun kamu pergi.

- ▶ Ukuran : ALL SIZE FIT TO L

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Sablon Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 4 variasi warna Hijacket Oksana Original, pilih style favorit ukhti

#### Tabel Ukuran Hijacket Oksana Original


| Ukuran          | All Size        |
|:--------------- |:---------------:|
| Lingkar Dada    | 101-102         |
| Lingkar Lengan  | 40-42           |
| Panjang Tangan  | 55-57           |
| Panjang Badan   | 84-85           |