---
title: Hijacket Avia Black - HJ-AVA
description: Jual jaket muslimah Hijacket Avia Black - HJ-AVA
date: '2018-11-22T17:48:14+07:00'
slug: AVA-BLACK
tags:
  - avia
  - black
produk:
  - avia
brand:
  - hijacket
thumbnail: /images/avia-black.jpg
images:
  - /images/avia-black-1.jpg
  - /images/avia-black-2.jpg
  - /images/avia-black-3.jpg
  - /images/avia-black-4.jpg
  - /images/avia-black-5.jpg
  - /images/avia-black-6.jpg
  - /images/avia-black-7.jpg
  - /images/avia-black-8.jpg
sku: AVA-BLACK
badge: new
berat: 730 gram
color:
  - Black
size:
  - name: All Size
    price: 200000
  - name: XL
    price: 210000
stock: true
layout: multi-varian
---

Hijacket AVIA ORIGINAL dirancang khusus untuk Hijaber yang ingin tampil modis & sporty. Dengan model modis, dipadu bordir Hijacket dibagian dada dan gaya jari yang menguatkan aktualisasi diri sebagai hijaber.

- ▶ Ukuran : ALL SIZE FIT TO L

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Bordir Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 5 variasi warna Hijacket Avia Original, pilih style favorit ukhti

#### Tabel Ukuran Hijacket Avia Original

| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 84-85           | 84-85  	      |