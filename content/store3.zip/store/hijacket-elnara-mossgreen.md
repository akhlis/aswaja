---
title: Hijacket Elnara Mossgreen - HJ-ELN
description: Jual jaket muslimah Hijacket Elnara Mossgreen - HJ-ELN
date: '2018-11-22T17:48:14+07:00'
slug: ELN-MOSSGREEN
tags:
  - elnara
  - green
produk:
  - elnara
brand:
  - hijacket
thumbnail: /images/elnara-mossgreen.jpg
images:
  - /images/elnara-mossgreen-1.jpg
  - /images/elnara-mossgreen-2.jpg
  - /images/elnara-mossgreen-3.jpg
  - /images/elnara-mossgreen-4.jpg
  - /images/elnara-mossgreen-5.jpg
  - /images/elnara-mossgreen-6.jpg
  - /images/elnara-mossgreen-7.jpg
  - /images/elnara-mossgreen-8.jpg
sku: ELN-MOSSGREEN
badge: sale
berat: 730 gram
color:
  - Mossgreen
size:
  - name: All Size
    price: 200000
  - name: XL
    price: 210000
stock: true
layout: multi-varian
---

Hijacket ELNARA ORIGINAL ini didesain dengan gaya modern, stylish dan modist. Dengan sentuhan tali di pinggang dengan kedua saku menyamping menjadikannya kamu tampil glamour.

- ▶ Ukuran : ALL SIZE FIT TO L

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Sablon Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 6 variasi warna Hijacket Elnara Original, pilih style favorit ukhti

#### Tabel Ukuran Hijacket Elnara Original


| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 84-85           | 84-85  	      |