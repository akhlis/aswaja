---
title: Hijacket Vendulum Sparrow Red - HJ-VD
description: Jual jaket muslimah Hijacket Vendulum Sparrow Red - HJ-VD
date: '2018-04-04T17:48:14+07:00'
slug: VD-SPARROW-RED
tags:
  - vendulum
  - red
produk:
  - vendulum
brand:
  - hijacket
thumbnail: /images/vd-sparrow-red.jpg
images:
  - /images/vd-sparrow-red-1.jpg
  - /images/vd-sparrow-red-2.jpg
  - /images/vd-sparrow-red-3.jpg
  - /images/vd-sparrow-red-4.jpg
  - /images/vd-sparrow-red-5.jpg
sku: VD-SPARROW-RED
badge: sale
berat: 755 gram
color:
  - Sparrow Red
size:
  - name: All Size
    price: 210000
  - name: XL
    price: 220000
stock: true
layout: multi-varian
---

Hijacket Vendulum Original

- ▶️ Ukuran : ALL SIZE FIT TO L hingga XL (XL Nambah 10.000)

- ▶️ Material : Premium Fleece yang "SOFT TOUCH" langsung dari pabrik pengolah kain berpengalaman

- ▶️ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶️ Sablonan Berkualitas

- ▶️ Bukan sekedar fashion. Namun menguatkan "JATI DIRI / IDENTITAS" Hijaber yang modis dan stylish

Ada 4 Warna Favorit

#### Tabel Ukuran Hijacket Vendulum Original


| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 89-90           | 89-90  	      |