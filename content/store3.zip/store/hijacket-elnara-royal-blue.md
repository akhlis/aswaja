---
title: Hijacket Elnara Royal Blue - HJ-ELN
description: Jual jaket muslimah Hijacket Elnara Royal Blue - HJ-ELN
date: '2018-11-22T17:48:14+07:00'
slug: ELN-ROYAL-BLUE
tags:
  - elnara
  - navy
produk:
  - elnara
brand:
  - hijacket
thumbnail: /images/elnara-royal-blue.jpg
images:
  - /images/elnara-royal-blue-1.jpg
  - /images/elnara-royal-blue-2.jpg
  - /images/elnara-royal-blue-3.jpg
  - /images/elnara-royal-blue-4.jpg
  - /images/elnara-royal-blue-5.jpg
  - /images/elnara-royal-blue-6.jpg
  - /images/elnara-royal-blue-7.jpg
  - /images/elnara-royal-blue-8.jpg
sku: ELN-ROYAL-BLUE
badge: sale
berat: 730 gram
color:
  - Royal Blue
size:
  - name: All Size
    price: 200000
  - name: XL
    price: 210000
stock: true
layout: multi-varian
---

Hijacket ELNARA ORIGINAL ini didesain dengan gaya modern, stylish dan modist. Dengan sentuhan tali di pinggang dengan kedua saku menyamping menjadikannya kamu tampil glamour.

- ▶ Ukuran : ALL SIZE FIT TO L

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Sablon Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 6 variasi warna Hijacket Elnara Original, pilih style favorit ukhti

#### Tabel Ukuran Hijacket Elnara Original


| Ukuran          | All Size        | XL              |
|:--------------- |:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      |
| Lingkar Lengan  | 40-42           | 43-45  	      |
| Panjang Tangan  | 55-57           | 55-57  	      |
| Panjang Badan   | 84-85           | 84-85  	      |