---
title: Hijacket Urbanashion Royal Blue - HJ-UB
description: Jual jaket muslimah Hijacket Urbanashion Royal Blue - HJ-UB
date: '2018-04-04T17:48:14+07:00'
slug: UB-ROYAL-BLUE
tags:
  - urbanashion
  - navy
produk:
  - urbanashion
brand:
  - hijacket
thumbnail: /images/ub-royal-blue.jpg
images:
  - /images/ub-royal-blue-1.jpg
  - /images/ub-royal-blue-2.jpg
  - /images/ub-royal-blue-3.jpg
  - /images/ub-royal-blue-4.jpg
  - /images/ub-royal-blue-5.jpg
  - /images/ub-royal-blue-6.jpg
  - /images/ub-royal-blue-7.jpg
  - /images/ub-royal-blue-8.jpg
sku: UB-ROYAL-BLUE
badge: sale
berat: 755 gram
color:
  - Royal Blue
size:
  - name: All Size
    price: 190000
  - name: XL
    price: 200000
  - name: XXL
    price: 210000
stock: true
layout: multi-varian
---

HIJACKET URBANASHION ORIGINAL model Hijacket ini didesain khas bergaya urban yang berkesan elegan bikin penampilan Anda tambah berwibawa. Cocok untuk wanita karir atau muslimah profesional. Dengan model modis, dipadu tulisan beberapa nama negara, kantong, dan tali kerut agar lebih stylish.

- ▶️ Ukuran : ALL SIZE FIT TO L hingga XXL (XL Nambah 10.000 & XXL Nambah 20.000 Dari Harga All Size L)

- ▶️ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶️ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶️ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶️ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 11 variasi warna Hijacket Urbanashion Original

#### Tabel Ukuran Hijacket Urbanashion Original


| Ukuran          | All Size        | XL              | XXL             |
|:--------------- |:---------------:|:---------------:|:---------------:|
| Lingkar Dada    | 101-102         | 108-110	      | 118-120         |
| Lingkar Lengan  | 40-42           | 43-45  	      | 46-48           |
| Panjang Tangan  | 55-57           | 55-57  	      | 55-57           |
| Panjang Badan   | 93-95           | 93-95  	      | 93-95           |
