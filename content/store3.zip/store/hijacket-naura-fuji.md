---
title: Hijacket Naura Fuji - HJ-NR
description: Jual jaket muslimah Hijacket Naura Fuji - HJ-NR
date: '2018-11-22T17:48:14+07:00'
slug: NR-FUJI
tags:
  - naura
  - green
produk:
  - naura
brand:
  - hijacket
thumbnail: /images/naura-fuji.jpg
images:
  - /images/naura-fuji-1.jpg
  - /images/naura-fuji-2.jpg
  - /images/naura-fuji-3.jpg
  - /images/naura-fuji-4.jpg
  - /images/naura-fuji-5.jpg
  - /images/naura-fuji-6.jpg
  - /images/naura-fuji-7.jpg
  - /images/naura-fuji-8.jpg
sku: NR-FUJI
badge: new
berat: 730 gram
color:
  - Green
size: All Size
price: 200000
stock: true
---

Hijacket NAURA merupakan transisi dari model sporty rancangan pertama dari seri Hijacket. Dibuat untuk para Hijaber dengan gaya panjang, gaya jari, dan sablon chevron sebagai ikonik Hijacket yang membuat fashion modis namun tetap memikirkan sisi kebutuhan Hijaber.

- ▶ Ukuran : ALL SIZE FIT TO L

- ▶ Material : Premium Fleece yang “SOFT TOUCH” langsung dari pabrik pengolah kain berpengalaman

- ▶ Proses : Dibuat Handmade dengan penjahit terbaik yang berpengalaman lebih dari 5 tahun

- ▶ Sablonan Berkualitas

- ▶ Bukan sekedar fashion. Namun menguatkan “JATI DIRI / IDENTITAS” Hijaber yang modis dan stylish

- ▶ Foto & Video : 100% sama dengan hijacket yang diterima karena kami foto & video model sendiri.

Ada 4 variasi warna Hijacket Naura Original, pilih style favorit ukhti

#### Tabel Ukuran Hijacket Naura Original


| Ukuran          | All Size        |
|:--------------- |:---------------:|
| Lingkar Dada    | 101-102         |
| Lingkar Lengan  | 40-42           |
| Panjang Tangan  | 55-57           |
| Panjang Badan   | 84-85           |