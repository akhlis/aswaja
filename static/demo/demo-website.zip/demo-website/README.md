## Simple Live Editor - [DEMO](https://willianjusten.com.br/dumb-codepen/)

![Preview do Site](/img/cover.png)

> A simple live editor with very few lines of code. Created to study purposes.
