'use strict';

// Listening for clicks on each button

let troli = (JSON.parse(localStorage.getItem('troli')) || []);
const troliDOM = document.querySelector('.troli');
const masukTroliDOM = document.querySelector('[data-action="TAMBAH_KE_CART"]');
let qtyItem = 1;
const tambahItem = document.querySelector('.tambah-item');
const kurangItem = document.querySelector('.kurang-item');

if (tambahItem) {
    tambahItem.addEventListener('click', () => tambahItemProduk());

    function tambahItemProduk() {
        document.querySelector('.jumlah-item').innerText = ++qtyItem;
    }
}
if (kurangItem) {
    kurangItem.addEventListener('click', () => kurangItemProduk());

    function kurangItemProduk() {
        document.querySelector('.jumlah-item').innerText = --qtyItem;
    }
}


if (troli.length > 0) {
    troli.forEach((troliItem, index, item) => {
        const produk = troliItem;
        insertProdukToDOM(produk);
        countTroliTotal();



        if (item[item.length - 1].nama === produk.nama) {
            tekanButtons(masukTroliDOM);
        }




    });
}

if (masukTroliDOM) {
    masukTroliDOM.addEventListener('click', () => {
        const produk = {
            gambar: document.querySelector('.gambar-produk').getAttribute('src'),
            nama: document.querySelector('.nama-produk').innerText,
            harga: document.querySelector('.harga-produk').innerText,
            jumlah: document.querySelector('.jumlah-produk').innerText,
        };

        // Adding products to the cart
        const isInTroli = (troli.filter(troliItem => (troliItem.nama === produk.nama)).length > 0);

        if (!isInTroli) {

            insertProdukToDOM(produk);
            troli.push(produk);
            tekanButtons(masukTroliDOM);
            saveTroli();
        }
    });
}


function insertProdukToDOM(produk) {
    troliDOM.insertAdjacentHTML('beforeend', `
    <div class="troli__item">
      <img class="troli__item__image" src="${produk.gambar}" alt="${produk.nama}">
      <h3 class="troli__item__name">${produk.nama}</h3>
      <h3 class="troli__item__nama">${produk.nama}</h3>
      <h3 class="troli__item__price">${produk.harga}</h3>
      <h3 class="troli__item__quantity">${produk.jumlah} PCS</h3>
      <button class="btn btn--primary btn--small${(produk.jumlah === 1 ? ' btn--danger' : '')}" data-action="KURANG_PRODUK">&minus;</button>
      <button class="btn btn--primary btn--small" data-action="TAMBAH_PRODUK">&plus;</button>
      <button class="btn btn--danger btn--small" data-action="HAPUS_PRODUK">&times;</button>
    </div>
  `);

    addTroliFooter();
}

function tekanButtons(masukTroliDOM) {
    masukTroliDOM.innerText = 'Dalam Troli';

    // Increasing quantity
    const troliItemsDOM = troliDOM.querySelectorAll('.troli__item');
    troliItemsDOM.forEach((troliItemDOM, index, arr) => {
       
            troliItemDOM.querySelector('[data-action="TAMBAH_PRODUK"]').addEventListener('click', () => tambahProduk(troliItemDOM));
            troliItemDOM.querySelector('[data-action="KURANG_PRODUK"]').addEventListener('click', () => kurangProduk(troliItemDOM));
            troliItemDOM.querySelector('[data-action="HAPUS_PRODUK"]').addEventListener('click', () => hapusProduk(troliItemDOM));

            console.log(arr[index].querySelector('.troli__item__name').innerText + ' produk ' + index);
     
    });
}

// Increasing cart item quantity

function tambahProduk(troliItemDOM) {
    troli.forEach((troliItem, index, arr) => {
        if (troliItemDOM.querySelector('.troli__item__name').innerText === arr[index].nama) {
            troliItemDOM.querySelector('.troli__item__quantity').innerText = ++troliItem.jumlah + ' PCS';
            troliItemDOM.querySelector('.troli__item__nama').innerText = arr[index].nama + arr[index].jumlah;
            troliItemDOM.querySelector('.troli__item__quantity').style.color = "red";
            troliItemDOM.querySelector('[data-action="KURANG_PRODUK"]').classList.remove('btn--danger');
            saveTroli();
        }
    });
}

// Decreasing cart item quantity

function kurangProduk(troliItemDOM) {
    troli.forEach((troliItem, index, arr) => {
        if (troliItemDOM.querySelector('.troli__item__name').innerText === arr[index].nama) {
            if (troliItem.jumlah > 1) {
                troliItemDOM.querySelector('.troli__item__quantity').innerText = --troliItem.jumlah + ' PCS';
                troliItemDOM.querySelector('.troli__item__nama').innerText = arr[index].nama + arr[index].jumlah;
                troliItemDOM.querySelector('.troli__item__quantity').style.color = "black";
                saveTroli();
            } else {
                hapusProduk(troliItemDOM);
            }

            if (troliItem.jumlah === 1) {
                troliItemDOM.querySelector('[data-action="KURANG_PRODUK"]').classList.add('btn--danger');
            }
        }
    });
}

// Removing items from the cart

function hapusProduk(troliItemDOM) {
    troliItemDOM.classList.add('troli__item--removed');
    setTimeout(() => troliItemDOM.remove(), 250);
    saveTroli();

    if (troli.length < 1) {
        document.querySelector('.troli-footer').remove();
    }
}

// Add button to Clear the cart

function addTroliFooter() {
    if (document.querySelector('.troli-footer') === null) {
        troliDOM.insertAdjacentHTML('afterend', `
      <div class="troli-footer">
        <button class="btn btn--danger" data-action="CLEAR_TROLI">Clear Cart</button>
        <button class="btn btn--primary" data-action="CHECKOUT">Pay</button>
      </div>
    `);

        document.querySelector('[data-action="CLEAR_TROLI"]').addEventListener('click', () => clearTroli());
        document.querySelector('[data-action="CHECKOUT"]').addEventListener('click', () => checkout());
    }
}

function clearTroli() {
    troliDOM.querySelectorAll('.troli__item').forEach(troliItemDOM => {
        troliItemDOM.classList.add('troli__item--removed');
        setTimeout(() => troliItemDOM.remove(), 250);
    });

    troli = [];
    localStorage.removeItem('troli');
    document.querySelector('.troli-footer').remove();
}

// Calculate total Payment and render to DOM pay button
function countTroliTotal() {
    let troliTotal = 0;
    troli.forEach(troliItem => troliTotal += troliItem.jumlah * troliItem.harga);
    document.querySelector('[data-action="CHECKOUT"]').innerText = `Pay $${troliTotal}`;
}

function saveTroli() {
    localStorage.setItem('troli', JSON.stringify(troli));
    countTroliTotal()
}