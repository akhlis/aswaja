import Component from '/js/lib/component.js';
import store from '/js/store/index.js';

export default class cartList extends Component {
    
    // Pass our store instance and the HTML element up to the parent Component
    constructor() {
        super({
            store,
            element: document.querySelector('.cart')
        });
    }

    /**
     * React to state changes and render the component's HTML
     *
     * @returns {void}
     */
    render() {
        let self = this;

        // If there are no items to show, render a little status instead
        if(store.state.cartProducts.length === 0) {
            self.element.innerHTML = `<p class="no-items">You've done nothing yet 😢</p>`;
            return;
        }
        
        // Loop the items and generate a list of elements
        self.element.innerHTML = `
                ${store.state.cartProducts.map(product => {
                    return `
                    <div class="cart-checkout__item cart__item">
                        <img alt="${product.name}" src="${product.image}" class="cart-checkout__item-thumb cart__item__image" sizes="(max-width: 80px) 100vw, 80px">
                        <h3 class="cart-checkout__item-name cart__item__name">${product.name}${product.size}</h3>
                        <span class="cart-checkout__item-qty cart__item__quantity">${product.quantity}</span>
                        <button class="cart-checkout__item-remove" data-action="REMOVE_ITEM">
                            <svg aria-hidden="true" data-prefix="far" data-icon="trash-alt" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="trash-alt_svg__svg-inline--fa trash-alt_svg__fa-trash-alt trash-alt_svg__fa-w-14 trash-alt_svg__fa-2x cart-checkout__icon" width="16px" height="16px">
                            <path fill="currentColor" d="M268 416h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12zM432 80h-82.41l-34-56.7A48 48 0 0 0 274.41 0H173.59a48 48 0 0 0-41.16 23.3L98.41 80H16A16 16 0 0 0 0 96v16a16 16 0 0 0 16 16h16v336a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V128h16a16 16 0 0 0 16-16V96a16 16 0 0 0-16-16zM171.84 50.91A6 6 0 0 1 177 48h94a6 6 0 0 1 5.15 2.91L293.61 80H154.39zM368 464H80V128h288zm-212-48h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12z"></path>
                            </svg>
                        </button>
                        <span class="cart-checkout__item-price cart__item__price">${product.price}</span>
                    </div>
                    `
                }).join('')}
        `;
        
        // Find all the buttons in the list and when they are clicked, we dispatch a 
        // `clearItem` action which we pass the current item's index to
        self.element.querySelectorAll('[data-action="REMOVE_ITEM"]').forEach((button, index) => {
            button.addEventListener('click', () => {
                store.dispatch('removeProduct', index);
                store.dispatch('removeVariant', index);
                store.dispatch('removeCounter', index);
            });
        });
    }
};