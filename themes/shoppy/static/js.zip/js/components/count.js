import Component from '/js/lib/component.js';
import store from '/js/store/index.js';

export default class Count extends Component {
    constructor() {
        super({
            store,
            element: document.querySelector('.product-counter__qty')
        });
    }
    
    /**
     * React to state changes and render the component's HTML
     *
     * @returns {void}
     */
    render() {
        let self = this;

        self.element.innerHTML = `
            <span>${store.state.counter}</span>
        `;
    }
}
