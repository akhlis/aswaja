export default {
    cartProducts: [],
    variants: [],
    counter: 3,
    counters: [],
};
