export default {
    ADD_PRODUCT(state, product) {
        state.cartProducts.push(product);
        
        return state;
    },
    REMOVE_PRODUCT(state, index) {
        state.cartProducts.splice(index, 1);
        
        return state;
    },
    ADD_VARIANT(state, product) {
        state.variants.push(product);
        
        return state;
    },
    REMOVE_VARIANT(state, index) {
        state.variants.splice(index, 1);
        
        return state;
    },
    ADD_COUNTER(state, product) {
        state.counters.push(product);
        
        return state;
    },
    REMOVE_COUNTER(state, index) {
        state.counters.splice(index, 1);
        
        return state;
    },
    INCREMENT_COUNT(state, value) {
        state.counter += value
        
        return state;
    },
    DECREMENT_COUNT(state, value) {
        state.counter -= value
        
        return state;
    },
};
