import actions from '/js/store/actions.js';
import mutations from '/js/store/mutations.js';
import state from '/js/store/state.js';
import Store from '/js/store/store.js';

export default new Store({
    actions,
    mutations,
    state
});
