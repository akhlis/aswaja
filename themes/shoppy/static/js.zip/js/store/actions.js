export default {
    addProduct(context, product) {
        context.commit('ADD_PRODUCT', product);
    },
    removeProduct(context, index) {
        context.commit('REMOVE_PRODUCT', index);
    },
    addVariant(context, product) {
        context.commit('ADD_VARIANT', product);
    },
    removeVariant(context, index) {
        context.commit('REMOVE_VARIANT', index);
    },
    addCounter(context, product) {
        context.commit('ADD_COUNTER', product);
    },
    removeCounter(context, index) {
        context.commit('REMOVE_COUNTER', index);
    },
    increment(context, value) {
        context.commit('INCREMENT_COUNT', value);
    },
    decrement(context, value) {
        context.commit('DECREMENT_COUNT', value);
    },
};
