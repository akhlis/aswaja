'use strict';

// Listening for clicks on each button

let cart = (JSON.parse(localStorage.getItem('cart')) || []);
const cartDOM = document.querySelector('.cart');
const addToCartButtonDOM = document.querySelector('[data-action="ADD_TO_CART"]');
let qtyItem = 1;
const tambahItem = document.querySelector('.tambah-item');
const kurangItem = document.querySelector('.kurang-item');
const productSizeButtons = document.querySelectorAll('.product__size');
const cardProductsPrice = document.querySelectorAll('.product__price, .card-product__price');

const buttons = document.querySelectorAll('.product__size');

buttons.forEach(function (button) {
    button.addEventListener('click', function () {
        toggleClass(buttons, this);
    });
});

function toggleClass(buttons, buttonToActivate) {
    let harga = parseFloat(buttonToActivate.value);
    document.querySelector('.product__price').innerText = harga.toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });

    buttons.forEach(function (btn) {
        btn.classList.remove('active');
    });
    buttonToActivate.classList.add('active');
}

if (cardProductsPrice) {
    cardProductsPrice.forEach(cardProductPrice => {
        let harga = parseFloat(cardProductPrice.innerText);
        cardProductPrice.innerText = harga.toLocaleString('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
    })
}




if (tambahItem) {
    tambahItem.addEventListener('click', () => tambahItemProduk());

    function tambahItemProduk() {
        document.querySelector('.product__qty').innerText = ++qtyItem;
    }
}
if (kurangItem) {
    kurangItem.addEventListener('click', () => kurangItemProduk());

    function kurangItemProduk() {
        document.querySelector('.product__qty').innerText = --qtyItem;
    }
}



if (cart.length > 0) {
    cart.forEach((cartItem, index, item) => {
        const product = cartItem;
        insertItemToDOM(product);
        countCartTotal();

        if (item[item.length - 1].name === product.name) {
            handleActionButtons(addToCartButtonDOM, product);
        }

    });
}

if (addToCartButtonDOM) {
    addToCartButtonDOM.addEventListener('click', () => {
        const productDOM = addToCartButtonDOM.parentNode;
        const product = {
            image: document.querySelector('.product__image:first-child').getAttribute('src'),
            name: document.querySelector('.product__name').innerText,
            price: document.querySelector('.product__price').innerText,
            quantity: document.querySelector('.product__qty').innerText,
        };

        // Adding products to the cart

        const isInCart = (cart.filter(cartItem => (cartItem.name === product.name)).length > 0);

        if (!isInCart) {
            insertItemToDOM(product);
            cart.push(product);
            saveCart();
            handleActionButtons(addToCartButtonDOM, product);
        }
    });
}

// Inserting cart items and small buttons to the cart DOM

function insertItemToDOM(product) {
    cartDOM.insertAdjacentHTML('beforeend', `
    <div class="cart__item">
      <img class="cart__item__image" src="${product.image}" alt="${product.name}">
      <h3 class="cart__item__name">${product.name}</h3>
      <h3 class="cart__item__price">${product.price}</h3>
      <button class="btn btn--primary btn--small${(product.quantity === 1 ? ' btn--danger' : '')}" data-action="DECREASE_ITEM">&minus;</button>
      <h3 class="cart__item__quantity">${product.quantity}</h3>
      <button class="btn btn--primary btn--small" data-action="INCREASE_ITEM">&plus;</button>
      <button class="btn btn--danger btn--small" data-action="REMOVE_ITEM">&times;</button>
    </div>
  `);

    addCartFooter();
}

// Cart buttons event handers
function handleActionButtons(addToCartButtonDOM, product) {
    if (addToCartButtonDOM) {
        addToCartButtonDOM.innerText = 'In Cart';
    }
    // Increasing quantity

    const cartItemsDOM = cartDOM.querySelectorAll('.cart__item');
    cartItemsDOM.forEach((cartItemDOM, index, arr) => {
        if (cartItemDOM.querySelector('.cart__item__name').innerText === arr[index].querySelector('.cart__item__name').innerText) {
            cartItemDOM.querySelector('[data-action="INCREASE_ITEM"]').addEventListener('click', () => increaseItem(product, cartItemDOM));
            cartItemDOM.querySelector('[data-action="DECREASE_ITEM"]').addEventListener('click', () => decreaseItem(product, cartItemDOM, addToCartButtonDOM));
            cartItemDOM.querySelector('[data-action="REMOVE_ITEM"]').addEventListener('click', () => removeItem(product, cartItemDOM, addToCartButtonDOM));

            console.log(arr[index].querySelector('.cart__item__name').innerText + ' produk ' + index);
        }
    });
}

// Increasing cart item quantity

function increaseItem(product, cartItemDOM) {
    cart.forEach((cartItem, index, arr) => {
        if (cartItemDOM.querySelector('.cart__item__name').innerText === arr[index].name) {
            cartItemDOM.querySelector('.cart__item__quantity').innerText = ++cartItem.quantity;
            cartItemDOM.querySelector('.cart__item__quantity').style.color = "red";
            cartItemDOM.querySelector('[data-action="DECREASE_ITEM"]').classList.remove('btn--danger');
            saveCart();
        }
    });
}

// Decreasing cart item quantity

function decreaseItem(product, cartItemDOM, addToCartButtonDOM) {
    cart.forEach((cartItem, index, arr) => {
        if (cartItemDOM.querySelector('.cart__item__name').innerText === arr[index].name) {
            if (cartItem.quantity > 1) {
                cartItemDOM.querySelector('.cart__item__quantity').innerText = --cartItem.quantity;
                cartItemDOM.querySelector('.cart__item__quantity').style.color = "blue";
                saveCart();
            } else {
                removeItem(product, cartItemDOM, addToCartButtonDOM);
            }

            if (cartItem.quantity === 1) {
                cartItemDOM.querySelector('[data-action="DECREASE_ITEM"]').classList.add('btn--danger');
            }
        }
    });
}

// Removing items from the cart

function removeItem(product, cartItemDOM, addToCartButtonDOM) {
    cartItemDOM.classList.add('cart__item--removed');
    setTimeout(() => cartItemDOM.remove(), 250);
    cart = cart.filter(cartItem => cartItem.name !== product.name);
    saveCart();
    addToCartButtonDOM.innerText = 'Add To Cart';
    addToCartButtonDOM.disabled = false;

    if (cart.length < 1) {
        document.querySelector('.cart-footer').remove();
    }
}

// Add button to Clear the cart

function addCartFooter() {
    if (document.querySelector('.cart-footer') === null) {
        cartDOM.insertAdjacentHTML('afterend', `
      <div class="cart-footer">
        <button class="btn btn--danger" data-action="CLEAR_CART">Clear Cart</button>
        <button class="btn btn--primary" data-action="CHECKOUT">Pay</button>
      </div>
    `);

        document.querySelector('[data-action="CLEAR_CART"]').addEventListener('click', () => clearCart());
        document.querySelector('[data-action="CHECKOUT"]').addEventListener('click', () => checkout());
    }
}

// Clearing the cart event

function clearCart() {
    cartDOM.querySelectorAll('.cart__item').forEach(cartItemDOM => {
        cartItemDOM.classList.add('cart__item--removed');
        setTimeout(() => cartItemDOM.remove(), 250);
    });

    cart = [];
    localStorage.removeItem('cart');
    document.querySelector('.cart-footer').remove();

    addToCartButtonDOM.innerText = 'Add To Cart';
    addToCartButtonDOM.disabled = false;
}

// Using Paypal API, add the paypal form attribute and insert it to the DOM

function checkout() {
    let paypalFormHTML = `
    <form id="paypal-form" action="https://www.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="cmd" value="_cart">
      <input type="hidden" name="upload" value="1">
      <input type="hidden" name="business" value="adrian@webdev.tube">
  `;

    cart.forEach((cartItem, index) => {
        ++index;
        paypalFormHTML += `
      <input type="hidden" name="item_name_${index}" value="${cartItem.name}">
      <input type="hidden" name="amount_${index}" value="${cartItem.price}">
      <input type="hidden" name="quantity_${index}" value="${cartItem.quantity}">
    `;
    });

    paypalFormHTML += `
      <input type="submit" value="PayPal">
    </form>
    <div class="overlay"></div>
  `;

    document.querySelector('body').insertAdjacentHTML('beforeend', paypalFormHTML);
    document.getElementById('paypal-form').submit();
}

// Calculate total Payment and render to DOM pay button

function countCartTotal() {
    let cartTotal = 0;
    cart.forEach(cartItem => cartTotal += cartItem.quantity * parseInt(cartItem.price.replace(/\D/g, '')));
    document.querySelector('[data-action="CHECKOUT"]').innerText = `Bayar ${cartTotal.toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    })}`;
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    countCartTotal();
}



// slider
function Slider(el) {
    this.el = document.querySelector(el);
    this.init();
}

Slider.prototype = {
    init: function () {
        this.navItems = this.el.querySelectorAll('.image-slider__navigation-item');
        this.container = this.el.querySelector('.image-slider__container');
        this.navigate();
    },

    navigate: function () {
        for (var i = 0; i < this.navItems.length; i++) {
            var navItem = this.navItems[i];
            this.slide(navItem);
        }
    },

    slide: function (link) {
        var self = this;
        link.addEventListener('click', function () {
            var index = parseInt(link.getAttribute('data-slide'), 10) + 1;
            var allSlide = self.el.querySelectorAll('.image-slider__item');
            var activeSlide = self.el.querySelector('.image-slider__item:nth-child(' + index + ')');

            self.container.style.left = '-' + activeSlide.offsetLeft + 'px';

            allSlide.forEach(function (btn) {
                btn.classList.remove('activeSlider');
            });
            activeSlide.classList.add('activeSlider');

        })
    },
    animate: function () {},
    setCurrentLink: function () {}
};

document.addEventListener('DOMContentLoaded', function () {
    var mySlider = new Slider('.image-slider');
    var slideImages = document.querySelectorAll('.image-slider__navigation-item');
    var productImages = document.querySelectorAll('.product__image');

    slideImages.forEach((slideImage, index, arr) => {
        arr[index].classList.add('myslider-' + index + '');
        arr[0].classList.add('aktif-slide');
        arr[index].setAttribute('data-slide', '' + index + '');
    });

    productImages.forEach((productImage, index, arr) => {
        arr[0].classList.add('aktif-image');
    });
})