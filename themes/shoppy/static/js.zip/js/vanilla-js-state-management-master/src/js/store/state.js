export default {
    items: [
        'I made this',
        'Another thing'
    ]
};
