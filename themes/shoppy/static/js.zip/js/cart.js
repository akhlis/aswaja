'use strict';

// Listening for clicks on each button
let cart = (JSON.parse(localStorage.getItem('cart')) || []);
const cartDOM = document.querySelector('.cart');
const checkoutDOM = document.querySelector('.checkout-list');
const addToCartButtonDOM = document.querySelector('[data-action="ADD_TO_CART"]');
let qtyItem = 1;
const addQty = document.querySelector('.add-qty');
const subtractQty = document.querySelector('.subtract-qty');
const variants = document.querySelectorAll('.product-variant__button');
const cardProductsPrice = document.querySelectorAll('.product__price, .card-product__price');
const cartPopup = document.querySelector('.navbar-cart__button');
const prov = document.getElementById("prov");
const kab = document.getElementById("kab");
const kec = document.getElementById("kec");
const kurir = document.getElementById("kurir");
const userName = document.getElementById("name");
const userPhone = document.getElementById("phone");
const userAddress = document.getElementById("alamat");
const userPostcode = document.getElementById("kode-pos");
const buttonOrder = document.querySelector('.checkout-form__btn');

function localNumber(angka) {
    let myNumber = parseFloat(angka).toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
    return myNumber;
}

function toAngka(angka) {
    let myNumber = parseInt(angka.replace(/\D/g, ''));
    return myNumber;
}

//card produk
if (cardProductsPrice) {
    cardProductsPrice.forEach(cardProductPrice => {
        let cardPrice = parseFloat(cardProductPrice.innerText);
        cardProductPrice.innerText = localNumber(cardPrice);
    })
}

if (addQty) {
    addQty.addEventListener('click', () => qtyProduct());

    function qtyProduct() {
        document.querySelector('.product__qty').innerText = ++qtyItem;
    }
}

if (subtractQty) {
    subtractQty.addEventListener('click', () => subtractQtyProduct());

    function subtractQtyProduct() {
        document.querySelector('.product__qty').innerText = --qtyItem;
    }
}

//cart popup
if (cartPopup) {
    cartPopup.addEventListener('click', () => {
        const popupCheckout = document.querySelector('.cart-checkout');
        popupCheckout.classList.toggle('cart-active');
    });
}

// new size
variants.forEach((variant, index, arr) => {
    arr[0].classList.add('variant-active');
    variant.addEventListener('click', () => {
        let variantPrice = parseFloat(variant.getAttribute("data-price"));
        document.querySelector('.product__price').innerText = localNumber(variantPrice);
        document.querySelector('.product__size').innerText = variant.getAttribute("data-size");
        variants.forEach(btn => {
            btn.classList.remove('variant-active');
        });
        variant.classList.add('variant-active');
    });
});

//cart
if (cart.length > 0) {
    cart.forEach((cartItem, index, item) => {
        const product = cartItem;
        insertItemToDOM(product);
        if (checkoutDOM) {
            insertItemToCheckout(product);
        }
        countCartTotal();

        if (item[item.length - 1].name + item[item.length - 1].size === product.name + product.size) {
            handleActionButtons();

            console.log(item[item.length - 1].name + item[item.length - 1].size)
            console.log(product.name + product.size)
            console.log(cartItem.name + cartItem.size)
        }
    });
}

if (addToCartButtonDOM) {
    addToCartButtonDOM.addEventListener('click', () => {
        const product = {
            image: document.querySelector('.product__image:first-child').getAttribute('src'),
            name: document.querySelector('.product__name').innerText,
            price: document.querySelector('.product__price').innerText,
            size: document.querySelector('.product__size').innerText,
            weight: document.querySelector('.variant-active').getAttribute("data-weight"),
            quantity: document.querySelector('.product__qty').innerText,
            sku: document.querySelector('.product__sku').innerText,
            brand: document.querySelector('.product__brand').innerText,
        };

        // Adding products to the cart
        const isInCart = (cart.filter(cartItem => (cartItem.name + cartItem.size === product.name + product.size)).length > 0);

        if (!isInCart) {
            insertItemToDOM(product);
            if (checkoutDOM) {
                insertItemToCheckout(product);
            }
            cart.push(product);
            saveCart();
            handleActionButtons();
        }

        console.log(isInCart)
    });
}

// Inserting cart items and small buttons to the cart DOM

function insertItemToDOM(product) {
    cartDOM.insertAdjacentHTML('beforeend', `
    <div class="cart-checkout__item cart__item">
        <img alt="${product.name}" src="${product.image}" class="cart-checkout__item-thumb cart__item__image" sizes="(max-width: 80px) 100vw, 80px">
        <h3 class="cart-checkout__item-name cart__item__name">${product.name}${product.size}</h3>
        <span class="cart-checkout__item-qty cart__item__quantity">${product.quantity}</span>
        <button class="cart-checkout__item-remove" data-action="REMOVE_ITEM">
            <svg aria-hidden="true" data-prefix="far" data-icon="trash-alt" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="trash-alt_svg__svg-inline--fa trash-alt_svg__fa-trash-alt trash-alt_svg__fa-w-14 trash-alt_svg__fa-2x cart-checkout__icon" width="16px" height="16px">
            <path fill="currentColor" d="M268 416h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12zM432 80h-82.41l-34-56.7A48 48 0 0 0 274.41 0H173.59a48 48 0 0 0-41.16 23.3L98.41 80H16A16 16 0 0 0 0 96v16a16 16 0 0 0 16 16h16v336a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V128h16a16 16 0 0 0 16-16V96a16 16 0 0 0-16-16zM171.84 50.91A6 6 0 0 1 177 48h94a6 6 0 0 1 5.15 2.91L293.61 80H154.39zM368 464H80V128h288zm-212-48h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12z"></path>
            </svg>
        </button>
        <span class="cart-checkout__item-price cart__item__price">${product.price}</span>
    </div>
    `);
    addCartFooter();
}

function insertItemToCheckout(product) {
    checkoutDOM.insertAdjacentHTML('beforeend', `
        <li class="checkout-product">
            <img alt="${product.name}" src="${product.image}" class="product-image">
            <h3 class="checkout-product__name">${product.name}${product.size}</h3>
            <span class="checkout-product__price-total">${product.price}</span>
            <div class="checkout-product__counter">
                <button class="checkout-product__decrease product-counter__btn btn--small${(product.quantity === 1 ? ' btn--danger' : '')}" data-action="DECREASE_ITEM">&minus;</button>
                <span class="checkout-product__qty product-counter__qty">${product.quantity}</span>
                <button class="checkout-product__increase product-counter__btn" data-action="INCREASE_ITEM">&plus;</button>
            </div>
            <button class="checkout-product__remove" data-action="REMOVE_ITEM">
                <svg aria-hidden="true" data-prefix="far" data-icon="trash-alt" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="trash-alt_svg__svg-inline--fa trash-alt_svg__fa-trash-alt trash-alt_svg__fa-w-14 trash-alt_svg__fa-2x grid-cart__icon" width="16px" height="16px"><path fill="currentColor" d="M268 416h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12zM432 80h-82.41l-34-56.7A48 48 0 0 0 274.41 0H173.59a48 48 0 0 0-41.16 23.3L98.41 80H16A16 16 0 0 0 0 96v16a16 16 0 0 0 16 16h16v336a48 48 0 0 0 48 48h288a48 48 0 0 0 48-48V128h16a16 16 0 0 0 16-16V96a16 16 0 0 0-16-16zM171.84 50.91A6 6 0 0 1 177 48h94a6 6 0 0 1 5.15 2.91L293.61 80H154.39zM368 464H80V128h288zm-212-48h24a12 12 0 0 0 12-12V188a12 12 0 0 0-12-12h-24a12 12 0 0 0-12 12v216a12 12 0 0 0 12 12z"></path></svg>
                <span>Hapus</span>
            </button>
            <span class="checkout-product__price">${product.price}</span><span class="checkout-product__weight">${product.weight}</span>
        </li>
    `);
}

// Cart buttons event handers
function handleActionButtons() {
    const cartItemsDOM = cartDOM.querySelectorAll('.cart__item');
    cartItemsDOM.forEach(cartItemDOM => {
        cartItemDOM.querySelector('[data-action="REMOVE_ITEM"]').addEventListener('click', () =>
            removeCartItem(cartItemDOM));
    });

    if (checkoutDOM) {
        const checkoutItemsDOM = checkoutDOM.querySelectorAll('.checkout-product');
        checkoutItemsDOM.forEach(checkoutItemDOM => {
            checkoutItemDOM.querySelector('[data-action="INCREASE_ITEM"]').addEventListener('click', () => increaseItem(checkoutItemDOM));
            checkoutItemDOM.querySelector('[data-action="DECREASE_ITEM"]').addEventListener('click', () => decreaseItem(checkoutItemDOM));
            checkoutItemDOM.querySelector('[data-action="REMOVE_ITEM"]').addEventListener('click', () => removeItem(checkoutItemDOM));
        });
    }
}

// Removing items from the cart
function removeCartItem(cartItemDOM) {
    cartItemDOM.classList.add('cart__item--removed');
    setTimeout(() => cartItemDOM.remove(), 250);
    cart = cart.filter(cartItem => cartItem.name + cartItem.size !== cartItemDOM.querySelector('.cart-checkout__item-name').innerText);
    saveCart();

    if (cart.length < 1) {
        document.querySelector('.cart-footer').remove();
    }
}

// Clearing the cart event
function clearCart() {
    cartDOM.querySelectorAll('.cart__item').forEach(cartItemDOM => {
        cartItemDOM.classList.add('cart__item--removed');
        setTimeout(() => cartItemDOM.remove(), 250);
    });

    if (checkoutDOM) {
        const checkoutItemsDOM = checkoutDOM.querySelectorAll('.checkout-product');
        checkoutItemsDOM.forEach(checkoutItemDOM => {
            checkoutItemDOM.classList.add('checkout-product--removed');
            setTimeout(() => checkoutItemDOM.remove(), 250);
        });
    }

    cart = [];
    localStorage.removeItem('cart');
    document.querySelector('.cart-footer').remove();
}

// Increasing checkout item quantity
function increaseItem(checkoutItemDOM) {
    cart.forEach((cartItem, index, arr) => {
        const itemName = checkoutItemDOM.querySelector('.checkout-product__name').innerText;
        if (itemName === cartItem.name + cartItem.size) {
            checkoutItemDOM.querySelector('.checkout-product__qty').innerText = ++cartItem.quantity;
            let jml = checkoutItemDOM.querySelector('.checkout-product__qty').innerText;
            let harga = parseInt(checkoutItemDOM.querySelector('.checkout-product__price').innerText.replace(/\D/g, ''));
            checkoutItemDOM.querySelector('.checkout-product__price-total').innerText = localNumber((jml * harga));
            checkoutItemDOM.querySelector('.checkout-product__qty').style.color = "red";
            checkoutItemDOM.querySelector('[data-action="DECREASE_ITEM"]').classList.remove('btn--danger');
            saveCart();
        }
    });
}

// Decreasing cart item quantity

function decreaseItem(checkoutItemDOM) {
    cart.forEach((cartItem, index, arr) => {
        const itemName = checkoutItemDOM.querySelector('.checkout-product__name').innerText;
        if (itemName === cartItem.name + cartItem.size) {
            if (cartItem.quantity > 1) {
                checkoutItemDOM.querySelector('.checkout-product__qty').innerText = --cartItem.quantity;
                let jml = checkoutItemDOM.querySelector('.checkout-product__qty').innerText;
                let harga = parseInt(checkoutItemDOM.querySelector('.checkout-product__price').innerText.replace(/\D/g, ''));
                checkoutItemDOM.querySelector('.checkout-product__price-total').innerText = localNumber((jml * harga));
                checkoutItemDOM.querySelector('.checkout-product__qty').style.color = "blue";
                saveCart();
            } else {
                removeItem(checkoutItemDOM);
            }
        }

        if (checkoutItemDOM.quantity === 1) {
            checkoutItemDOM.querySelector('[data-action="DECREASE_ITEM"]').classList.add('btn--danger');
        }
    });
}

function removeItem(checkoutItemDOM) {
    checkoutItemDOM.classList.add('checkout__item--removed');
    setTimeout(() => checkoutItemDOM.remove(), 250);
    cart = cart.filter(cartItem => cartItem.name + cartItem.size !== checkoutItemDOM.querySelector('.checkout-product__name').innerText);
    saveCart();

    if (cart.length < 1) {
        document.querySelector('.cart-footer').remove();
    }
}

// Add button to Clear the cart
function addCartFooter() {
    if (document.querySelector('.cart-footer') === null) {
        cartDOM.insertAdjacentHTML('afterend', `
        <div class="cart-info cart-footer">
            <a class="cart-checkout__item-btn" href="/cart">Checkout <span class="cart-checkout__now"></span></a>
            <button class="cart-checkout__item-btn" data-action="CLEAR_CART">Clear Cart</button>
        </div>
    `);
        document.querySelector('[data-action="CLEAR_CART"]').addEventListener('click', () => {
            clearCart();
            countCartTotal();
        });
    }
}



// Using Paypal API, add the paypal form attribute and insert it to the DOM

function checkout() {
    let paypalFormHTML = `
    <form id="paypal-form" action="https://www.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="cmd" value="_cart">
      <input type="hidden" name="upload" value="1">
      <input type="hidden" name="business" value="adrian@webdev.tube">
  `;

    cart.forEach((cartItem, index) => {
        ++index;
        paypalFormHTML += `
      <input type="hidden" name="item_name_${index}" value="${cartItem.name}">
      <input type="hidden" name="amount_${index}" value="${cartItem.price}">
      <input type="hidden" name="quantity_${index}" value="${cartItem.quantity}">
    `;
    });

    paypalFormHTML += `
      <input type="submit" value="PayPal">
    </form>
    <div class="overlay"></div>
  `;

    document.querySelector('body').insertAdjacentHTML('beforeend', paypalFormHTML);
    document.getElementById('paypal-form').submit();
}

// Calculate total Payment and render to DOM pay button

function countCartTotal() {
    let cartTotal = 0;

    cart.forEach(cartItem => {
        cartTotal += cartItem.quantity * toAngka(cartItem.price);
    });

    const checkoutTotal = localNumber(cartTotal);
    const checkoutButton = document.querySelector('[data-action="CHECKOUT"]');
    if (checkoutButton) {
        checkoutButton.innerText = `Bayar ${checkoutTotal}`;
    }
    document.querySelector('.cart-box').innerText = `${checkoutTotal}`;
    document.querySelector('.cart-checkout__now').innerText = `${checkoutTotal}`;

    if (checkoutDOM) {
        totalPay();
    }

}

function totalPay() {
    let courier = "JNE REG";
    waOrder(kurir.value, courier);

    userName.addEventListener('input', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        waOrder(kurir.value, courier);
    });
    userPhone.addEventListener('input', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        waOrder(kurir.value, courier);
    });
    userAddress.addEventListener('input', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        waOrder(kurir.value, courier);
    });
    userPostcode.addEventListener('input', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        waOrder(kurir.value, courier);
    });


    getJSON('/js/shipping.json').then(dataShipping => {
        let dataku = dataShipping;
        let provinsi = Object.keys(dataShipping); //countries - Object.keys return an array
        getProv(dataku, provinsi, prov); //push values to select one
        _kab(dataku);
        prov.addEventListener('change', () => {
            let courier = kurir.options[kurir.selectedIndex].dataset.courier;
            _kab(dataku);
            waOrder(kurir.value, courier);
        });
    })
}

function _kab(myData) {
    kab.innerHTML = ""; //clear the target select
    let kabupaten = myData[prov.options[prov.selectedIndex].getAttribute("data-prov")].regencies;
    getArea(kabupaten, kab);
    _kec(myData);
    kab.addEventListener('change', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        _kec(myData);
        waOrder(kurir.value, courier);
    });
}

function _kec(myData) {
    kec.innerHTML = "";
    let kecamatan = myData[prov.options[prov.selectedIndex].getAttribute("data-prov")].regencies[kab.options[kab.selectedIndex].getAttribute("data-area")].districts;
    getArea(kecamatan, kec);
    _kurir(myData);
    kec.addEventListener('change', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        _kurir(myData);
        waOrder(kurir.value, courier);
    });
}

function _kurir(myData) {
    kurir.innerHTML = "";
    let ekspedisi = myData[prov.options[prov.selectedIndex].getAttribute("data-prov")].regencies[kab.options[kab.selectedIndex].getAttribute("data-area")].districts[kec.options[kec.selectedIndex].getAttribute("data-area")].couriers;
    getEkspedisi(ekspedisi, kurir);
    kurir.addEventListener('change', () => {
        let courier = kurir.options[kurir.selectedIndex].dataset.courier;
        waOrder(kurir.value, courier);
    });
}

function getProv(myData, myProv, s) {
    myProv.forEach(item => {
        let opt = document.createElement("option");
        opt.value = myData[item].provinces;
        opt.setAttribute('data-prov', item);
        opt.innerHTML = myData[item].provinces;
        s.add(opt);
    });
}

function getArea(myArea, s) {
    myArea.forEach((item, index) => {
        let opt = document.createElement("option");
        opt.value = item.name;
        opt.setAttribute('data-area', index);
        opt.innerHTML = item.name;
        s.add(opt);
    });
}

function getEkspedisi(myEkspedisi, s) {
    myEkspedisi.forEach((ekspedisi, index) => {
        let opt = document.createElement("option");
        opt.value = ekspedisi.cost;
        opt.setAttribute('data-courier', ekspedisi.name);
        opt.innerHTML = ekspedisi.name + ' ' + localNumber(ekspedisi.cost);
        s.add(opt);
    });
}

function waOrder(costCourier, myCourier) {
    let getName = userName.value;
    let getPhone = userPhone.value;
    let getAddress = userAddress.value;
    let getPostcode = userPostcode.value;
    let getProvincy = prov.value;
    let getRegency = kab.value;
    let getDistrict = kec.value;
    let getCourier = costCourier;
    let cartTotal = 0;
    let weightTotal = 0;
    let sribu = 1000;

    cart.forEach(cartItem => {
        weightTotal += cartItem.quantity * cartItem.weight;
        cartTotal += cartItem.quantity * toAngka(cartItem.price);
    });

    const checkoutTotal = localNumber(cartTotal);
    let resultWeight = (Math.ceil(parseInt(weightTotal)) % parseInt(sribu) == 0) ? Math.ceil(parseInt(weightTotal)) : Math.round((parseInt(weightTotal) + parseInt(sribu) / 2) / parseInt(sribu)) * parseInt(sribu);
    let getWeight = resultWeight / 1000;
    const checkoutWeight = weightTotal.toLocaleString('id-ID');
    const checkoutCourier = localNumber(getWeight * getCourier);
    const payCourier = localNumber(getCourier);

    const productName = cart.map((product, index) => product.summary = '%0A' + product.quantity + 'x%20' + product.name + '%20' + product.size + '%20@' + localNumber(toAngka(product.price)) + '%20%3D%3D%3E%20%20%20%20%20%20%20%20' + localNumber(product.quantity * toAngka(product.price)));

    let checkoutPay = localNumber(getWeight * getCourier + cartTotal);
    let orderText = 'https://api.whatsapp.com/send?phone=6282324089982&text=Assalamu%27alaikum%20kak%2C%20saya%20mau%20order%20jaket%20Hijacket%20dengan%20rincian%20berikut%2C%0A%0ANama%20%20%20%20%20%3A%20' + getName + '%20%0ANo.%20HP%20%20%20%3A%20%' + getPhone + '%20%0AAlamat%20%20%20%3A%20' + getAddress + ',%20Kec.%20' + getDistrict + ',%20' + getRegency + ',%20Prov.%20' + getProvincy + '%20' + getPostcode + '%0A%0ARincian%20Pesanan%2C%0A_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_' + productName + '%0A_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%20_%2B%0ASubtotal%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20' + checkoutTotal + '%0ABerat%20Total%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20' + checkoutWeight + '%20gram%0AOngkir%20' + myCourier + '%20@' + payCourier + '%20%20%3D%3D%3E%20' + checkoutCourier + '%0A____________________________________%2B%0A*Jumlah%20Total*%20%20%20%20%20%20%20%20%20%20%20%20%20%20*' + checkoutPay + '*%0A%0AMohon%20segera%20diproses%20ya%20kak%21'


    document.querySelector('.checkout-product__subtotal').innerText = `${checkoutTotal}`;
    document.querySelector('.checkout-form__subtotal').innerText = `${checkoutTotal}`;
    document.querySelector('.checkout-form__weight-total').innerText = `${checkoutWeight}`;
    document.querySelector('.checkout-form__cost-courier').innerText = localNumber(getWeight * getCourier);
    document.querySelector('.pay-total').innerText = `${checkoutPay}`;

    buttonOrder.setAttribute('formaction', orderText);
    buttonOrder.classList.add('order-wa');

    const productItem = cart.map(product => `
    <div class="checkout-form__box">
        <div class="checkout-form--left">
            <p>${product.quantity} ${product.name}</p>
        </div>
        <div class="checkout-form--right">
            <span>${localNumber(product.quantity * toAngka(product.price))}</span>
        </div>
    </div>
    `).join('');

    document.querySelector('.checkout-form__detail-item').innerHTML = productItem;
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    countCartTotal();
}

function getJSON(path) {
    return fetch(path).then(response => response.json());
}



//slider
if (addQty) {
    var big_slider = tns({
        container: '.slider-for',
        navContainer: '.slider-nav',
        items: 1,
        navAsThumbnails: true,
        controls: false,
        controlsText: ["<", ">"],
        mouseDrag: false,
        rewind: true,
        swipeAngle: false,
        lazyload: true,
        lazyloadSelector: ".tns-lazy",
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 3500,
        autoplayButtonOutput: false,
        autoplayText: [
            "▶",
            "❚❚"
          ],
        speed: 400
    });


    var small_slider = tns({
        container: '.slider-nav',
        items: 5,
        gutter: 10,
        mouseDrag: true,
        nav: false,
        controls: false,
        swipeAngle: false,
        lazyload: true,
        lazyloadSelector: ".tns-lazy"
        //axis: "vertical"
    });

    //    let _prev = document.querySelector("[data-controls='prev']"),
    //        _next = document.querySelector("[data-controls='next']");
    //
    //    _prev.addEventListener('click', () => {
    //        small_slider.goTo('prev');
    //    });
    //    _next.addEventListener('click', () => {
    //        small_slider.goTo('next');
    //    });
}

let heroSlider = document.querySelector('.block__hero-slider');
if (heroSlider) {
    var hero_slider = tns({
        container: '.slider',
        items: 1,
        controlsText: ["<", ">"],
        controls: false,
        mouseDrag: true,
        arrowKeys: true,
        lazyload: true,
        lazyloadSelector: ".tns-lazy",
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 3500,
        autoplayButtonOutput: false,
        autoplayText: [
            "▶",
            "❚❚"
          ],
        animateIn: "tns-fadeIn",
        speed: 400
    });
}

var lazyLoadInstance = new LazyLoad({
    elements_selector: ".lazy"
    // ... more custom settings?
});

if (lazyLoadInstance) {
    lazyLoadInstance.update();
}