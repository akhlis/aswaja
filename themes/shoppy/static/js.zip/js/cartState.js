import store from '/js/store/index.js'; 
// Load up components
import Count from '/js/components/count.js';
import List from './components/cartList.js';


const cartDOM = document.querySelector('.cart');
const addToCartButtonDOM = document.querySelector('[data-action="ADD_TO_CART"]');
const variants = document.querySelectorAll('.product-variant__button');
const cardProductsPrice = document.querySelectorAll('.product__price, .card-product__price');
const cartPopup = document.querySelector('.navbar-cart__button');

function localNumber(angka) {
    let myNumber = parseFloat(angka).toLocaleString('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
    return myNumber;
}

function toAngka(angka) {
    let myNumber = parseInt(angka.replace(/\D/g, ''));
    return myNumber;
}


if (cartPopup) {
    cartPopup.addEventListener('click', () => {
        const popupCheckout = document.querySelector('.cart-checkout');
        popupCheckout.classList.toggle('cart-active');
    });
}

if (cardProductsPrice) {
    cardProductsPrice.forEach(cardProductPrice => {
        let cardPrice = parseFloat(cardProductPrice.innerText);
        cardProductPrice.innerText = localNumber(cardPrice);
    })
}

// new size
variants.forEach((variant, index, arr) => {
    arr[0].classList.add('variant-active');
    variant.addEventListener('click', () => {
        let variantPrice = parseFloat(variant.getAttribute("data-price"));
        document.querySelector('.product__price').innerText = localNumber(variantPrice);
        document.querySelector('.product__size').innerText = variant.getAttribute("data-size");
        variants.forEach(btn => {
            btn.classList.remove('variant-active');
        });
        variant.classList.add('variant-active');
    });
});

//add counter item
const decrementElem = document.querySelector('.subtract-qty');
const incrementElem = document.querySelector('.add-qty');
decrementElem.addEventListener('click', evt => {
    evt.preventDefault();
    store.dispatch('decrement', 1);
});
incrementElem.addEventListener('click', evt => {
    evt.preventDefault();
    store.dispatch('increment', 1);
});
// Instantiate components
const countInstance = new Count();
// Initial renders
countInstance.render();





addToCartButtonDOM.addEventListener('click', evt => {
    const product = {
        image: document.querySelector('.product__image:first-child').getAttribute('src'),
        name: document.querySelector('.product__name').innerText,
        price: document.querySelector('.product__price').innerText,
        size: document.querySelector('.product__size').innerText,
        weight: document.querySelector('.variant-active').getAttribute("data-weight"),
        quantity: document.querySelector('.product__qty').innerText,
        sku: document.querySelector('.product__sku').innerText,
        brand: document.querySelector('.product__brand').innerText,
    };
    
    const variant = product.size;
    const qty = store.state.counter;
    
    evt.preventDefault();
    
    store.dispatch('addProduct', product);
    store.dispatch('addVariant', variant);
    store.dispatch('addCounter', qty);
});

const listInstance = new List();

listInstance.render();









//slider

    var big_slider = tns({
        container: '.slider-for',
        navContainer: '.slider-nav',
        items: 1,
        navAsThumbnails: true,
        controls: false,
        controlsText: ["<", ">"],
        mouseDrag: false,
        rewind: true,
        swipeAngle: false,
        lazyload: true,
        lazyloadSelector: ".tns-lazy",
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 3500,
        autoplayButtonOutput: false,
        autoplayText: [
            "▶",
            "❚❚"
          ],
        speed: 400
    });


    var small_slider = tns({
        container: '.slider-nav',
        items: 5,
        gutter: 10,
        mouseDrag: true,
        nav: false,
        controls: false,
        swipeAngle: false,
        lazyload: true,
        lazyloadSelector: ".tns-lazy"
        //axis: "vertical"
    });

    //    let _prev = document.querySelector("[data-controls='prev']"),
    //        _next = document.querySelector("[data-controls='next']");
    //
    //    _prev.addEventListener('click', () => {
    //        small_slider.goTo('prev');
    //    });
    //    _next.addEventListener('click', () => {
    //        small_slider.goTo('next');
    //    });


let heroSlider = document.querySelector('.block__hero-slider');
if (heroSlider) {
    var hero_slider = tns({
        container: '.slider',
        items: 1,
        controlsText: ["<", ">"],
        controls: false,
        mouseDrag: true,
        arrowKeys: true,
        lazyload: true,
        lazyloadSelector: ".tns-lazy",
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 3500,
        autoplayButtonOutput: false,
        autoplayText: [
            "▶",
            "❚❚"
          ],
        animateIn: "tns-fadeIn",
        speed: 400
    });
}

var lazyLoadInstance = new LazyLoad({
    elements_selector: ".lazy"
    // ... more custom settings?
});

if (lazyLoadInstance) {
    lazyLoadInstance.update();
}
